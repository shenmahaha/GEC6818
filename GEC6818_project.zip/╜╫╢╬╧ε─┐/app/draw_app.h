#ifndef __DRAW_APP_H__
#define __DRAW_APP_H__
//绘画
extern int icon_app2_func();
//直线
extern void LCD_DrawLine(int x0, int y0, int x1, int y1, unsigned int color, int thickness);

#endif